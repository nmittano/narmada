CREATE TABLE designation_masters
(design_code number(3) primary key,
design_name varchar2(10));

INSERT INTO designation_masters values(001,'proffessor');
INSERT INTO designation_masters values(002,'accountant');
INSERT INTO designation_masters values(003,'proffessor');
INSERT INTO designation_masters values(004,'lecturer');
INSERT INTO designation_masters values(005,'proffessor');
INSERT INTO designation_masters values(006,'lecturer');
COMMIT;

                   
                                                                                    