CREATE TABLE department_masters
(dept_code number(2) primary key,
 dept_name varchar2(10));

INSERT INTO department_masters values(1,'ece');
INSERT INTO department_masters values(2,'eee');
INSERT INTO department_masters values(3,'cse');
INSERT INTO department_masters values(4,'mech');
INSERT INTO department_masters values(5,'it');
INSERT INTO department_masters values(6,'eni');
COMMIT;

 