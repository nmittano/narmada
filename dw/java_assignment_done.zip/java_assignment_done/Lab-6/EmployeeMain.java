package com.cg.oraapps.lab6;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

import com.cg.eis.bean.Employee;

public class EmployeeMain {
	static EmployeeServiceImpl service;
	public static void main(String[] args) {
		
		Employee emp = null; 
		Scanner sc = new Scanner(System.in);
		service = new EmployeeServiceImpl();
		System.out.println("Enter the number of employees in the company");
		int N = sc.nextInt();
		for(int i = 0; i < N; i++){
			emp = acceptDetails(sc);
			service.addEmployee(emp);
			service.findInsuranceScheme(emp);
		}
		new EmployeeMain().listIterator(service);
		sc.close();
		
	}
	
	public static Employee acceptDetails(Scanner sc){
		Employee emp = new Employee();
		
		
		System.out.println("Enter Employee id : ");
		emp.setEmployeeid(sc.nextInt());
		
		System.out.println("Enter Name : ");
		emp.setName(sc.next());
		
		System.out.println("Enter Salary : ");
		emp.setSalary(sc.nextDouble());
		
		System.out.println("Enter Designation :");
		emp.setDesignation(sc.next());
		
		
		return emp;
		
		
	}
	
	public static void printDetails(Employee emp){
		
		System.out.println("Employee ID : " + emp.getEmployeeid());
		System.out.println("Employee Name : " + emp.getName());
		System.out.println("Salary : " + emp.getSalary());
		System.out.println("Designation : " + emp.getDesignation());
		System.out.println("Insurance Scheme : " + emp.getInsuranceScheme());
	}
	
	public EmployeeServiceImpl getService(){
		return service;
	}
	public void listIterator(EmployeeServiceImpl service){
		HashMap<String, Employee> list = service.list;
		Set<String> keys = list.keySet();
		for(String empID : keys){
			printDetails(list.get(empID));
			System.out.println("\n");
		}
	}
}
