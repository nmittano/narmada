import java.util.Scanner;


public class PersonDetails {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the first name");
		String firstName = sc.next();
		
		System.out.println("enter last name");
		String lastName = sc.next();
		
		System.out.println("enter gender");
		String gender = sc.next();
		
		System.out.println("enter age");
		int age = sc.nextInt();
		
		System.out.println("First Name : " + firstName);
		System.out.println("Last Name : " + lastName);
		System.out.println("Gender : " + gender);
		System.out.println("Age : " + age);
		
		sc.close();
	}
}
