
public class PersonMain2 {
public static void main(String[] args) {
		
		Person2 p1 = new Person2("Bhuvan Prakash", "Karuturi", 'M', "8712734098");
		
		printDetails(p1);
	}

	public static void printDetails(Person2 p1){
		System.out.println("Person Details");
		System.out.println("-------------- \n");
		System.out.println("FirstName : " + p1.getFirstName());
		System.out.println("LastName : " + p1.getLastName());
		System.out.println("Gender : " + p1.getGender());
		System.out.println("Phone Number : " + p1.getPhoneNumber());
		
	}
}
