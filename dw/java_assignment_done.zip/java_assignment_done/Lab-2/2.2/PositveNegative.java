
public class PositveNegative {

	public static void main(String[] args) {
		if (Integer.parseInt(args[0]) < 0)
			System.out.println("Negative Number");
		else
			System.out.println("Positive Number");
	}

}
