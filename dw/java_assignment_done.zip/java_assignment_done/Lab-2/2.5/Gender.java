
public enum Gender {
	Male('M'), Female('F');
	char gender;
	Gender(char gender){
		this.gender = gender;
	}
}
